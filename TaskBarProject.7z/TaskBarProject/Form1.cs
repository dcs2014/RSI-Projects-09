﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using MathWorks.MATLAB.NET.Arrays;
using MathWorks.MATLAB.NET.Utility;


namespace TaskBar
{
    public partial class TaskBarForm : Form
    {
        public TaskBarForm()
        {
            InitializeComponent();

            FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;

            BackColor = Color.LightGray;

            this.AutoScroll = true;

            uc = new UserControl();
            uc.Dock = DockStyle.Fill;
            uc.BackColor = Color.Maroon;
            uc.AutoScroll = true;

            this.Controls.Add(uc);

            loaders.update_z_order(this);

            //loadspos();
        }

        public void setdirs(string s){



            loadexec(s);
        
        
        
        }


        public UserControl uc { get; set; }

        public bool islocked = true;

                      public void loadspos()
        {
            var screen = Screen.FromPoint(this.Location);
            this.Location = new Point(0,0);//new Point(screen.WorkingArea.Right - this.Width, screen.WorkingArea.Bottom - this.Height);
            //base.OnLoad(e);
        }
               private void locked(object sender, EventArgs e)
               {
                   if(islocked == true)
                     Location = new Point(0, 0);
               }

                      private void toolStripButton1_Click(object sender, EventArgs e)
                      {

                          if (FormBorderStyle == System.Windows.Forms.FormBorderStyle.None)
                          {
                              FormBorderStyle = System.Windows.Forms.FormBorderStyle.Sizable;
                             islocked = false;

                          }

                          else
                          {

                              FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
                              islocked = true;

                          }
                        
                      }


                      public TaskBar.loaders lds { get; set; }
        
        public void loadexec(){

            lds = new loaders();
            lds.register(this);
            string s = AppDomain.CurrentDomain.BaseDirectory;
            lds.getexecutables(s, this.uc, true);



        }



        public void loadexec(string s)
        {

            if (lds == null)
            {

                lds = new loaders();
                lds.register(this);

            }

            //string s = AppDomain.CurrentDomain.BaseDirectory;
            lds.getexecutables(s, this.uc, true);



        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            loadexec();
            loaders.update_z_order(this);
            
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        public bool getfolders { get; set; }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {

            if (getfolders == true)
            {

                toolStripButton4.Checked = false;
                getfolders = false;
            }
            else
            {
                toolStripButton4.Checked = true;
                getfolders = true;
            }

        }

        public void showFolders()
        {






        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            lds.enterupdirs();
        }

        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            
        }
    }
}
