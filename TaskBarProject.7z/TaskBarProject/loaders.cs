﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TaskBar
{
    public class loaders
    {

        public Control master { get; set; }

        public void register(Control c)
        {

            master = c;

        }

        public void unregister()
        {




        }


        public UserControl uc { get; set; }

        public void enterupdirs()
        {

            if (info == null)
                return;

            info = info.Parent;

            getexecutables(info.FullName, uc, true);

            update_z_order(master);


        }

        public DirectoryInfo info { get; set; }

        //public UserControl uc { get; set; }

        public void getexecutables(string path, Control c, bool folders){


            ArrayList L = new ArrayList();

            DirectoryInfo dirinfo = new DirectoryInfo(path);

            info = dirinfo;

            FileInfo []fs = dirinfo.GetFiles();

            uc = c as UserControl;


            if (folders == true)
            {
                DirectoryInfo[] ds = dirinfo.GetDirectories();


                foreach (DirectoryInfo dd in ds)
                {


                    string ext = Path.GetExtension(dd.FullName);


                    string file = dd.FullName;

                    Button b = (Button)createbutton(file, L);
                    b.BackColor = Color.LightSlateGray;

                }


            }



            foreach(FileInfo s in fs){


                string ext = Path.GetExtension(s.FullName);

                if(ext != ".exe" && ext != ".bat" && ext != ".lnks")
                    continue;

                string file = s.FullName;

                createbutton(file, L);


            }

            

            if (master == null)
                return;


            //master.Controls.Clear();


            c.Controls.Clear();

            append(L, c);

            update_z_order(master);
        }



        public Control createbutton(string text, ArrayList L){

            Button b = new Button();
            b.Anchor = AnchorStyles.Left | AnchorStyles.Top | AnchorStyles.Right;
            b.Text = Path.GetFileName(text);
            b.BackColor = Color.LightGoldenrodYellow;
            b.Tag = text;
            b.Click += new EventHandler(buttonhandler);
            L.Add(b);

            return b;
        }

        public void buttonhandler(object sender, EventArgs e)
        {

            Control c = sender as Control;

            if (c.Tag == null)
                return;

            string s = c.Tag as string;

            if (Directory.Exists(s) == true)
            {

                enterfolder(s);

                update_z_order(master);
            }
            else
            {

                launchexec(s);
            }

        }


        public void enterfolder(string s)
        {

            uc.Controls.Clear();

            getexecutables(s, uc, true);


        }


        public void append(ArrayList L, Control cc){

            Size size = cc.Size;

            Point loc = new Point(5, 5);
            
            int w = size.Width - 30;

            int h = 30;

            int hp = 5;

            int wp = 5;

            foreach (Control c in L)
            {

                c.Size = new Size(w, h);
                c.Location = new Point(wp, hp);

                hp = hp + 35;

                cc.Controls.Add(c);
            }

        }

        static public void update_z_order(Control p)
        {

            p.SuspendLayout();

            ArrayList L = new ArrayList();

            //foreach (Control c in Controls)
            //{

            //    L.Add(c);
            //}
            foreach (Control c in p.Controls)
            {
                L.Add(c);
            }

            foreach (Control c in L)
            {

                if (c.GetType() == typeof(ToolStripPanel) || c.GetType() == typeof(ToolStrip))
                    p.Controls.Remove(c);
                if (c.GetType().IsSubclassOf(typeof(MenuStrip)) == true || c.GetType() == typeof(MenuStrip))
                    p.Controls.Remove(c);

            }
            foreach (Control c in L)
            {
                if (c.GetType() == typeof(ToolStrip))
                    p.Controls.Add(c);
                if (c.GetType() == typeof(ToolStripPanel))
                    p.Controls.Add(c);
                if (c.GetType() == typeof(MenuStrip))
                    p.Controls.Add(c);
                if (c.GetType().IsSubclassOf(typeof(MenuStrip)) == true)
                    p.Controls.Add(c);

            }



            p.ResumeLayout();
        }

        public void launchexec(string s)
        {

            string ext = Path.GetExtension(s);

            if (ext == ".lnks")
            {

                loadfiles(s);
                return;

            }


            // Prepare the process to run
            ProcessStartInfo start = new ProcessStartInfo();
            // Enter in the command line arguments, everything you would enter after the executable name itself
            //start.Arguments = arguments;
            // Enter the executable to run, including the complete path
            start.FileName = s;
            // Do you want to show a console window?

            start.WorkingDirectory = Path.GetFullPath(s).Replace(Path.GetFileName(s),"" );

            if(Path.GetExtension(s) == ".bat")
            start.WindowStyle = ProcessWindowStyle.Normal;
            else
                start.WindowStyle = ProcessWindowStyle.Hidden;
            start.CreateNoWindow = false;

            // Run the external process & wait for it to finish
            using (Process proc = Process.Start(start))
            {
                //proc.WaitForExit();

                // Retrieve the app's exit code
                //exitCode = proc.ExitCode;
            }

        }

        public bool filepathsloaded = false;

        public void loadfiles(string s)
        {
            filepathsloaded = true;

            

            string []c = File.ReadAllLines(s);

            ArrayList L = new ArrayList();

            foreach (string e in c)
            {


                createbutton(e, L);

            }

             uc.Controls.Clear();

            append(L, uc);

            update_z_order(master);

        }

    }
}
